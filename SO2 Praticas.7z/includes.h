#pragma once

#include <fcntl.h>
#include <io.h>
#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <string.h>
#include <string>
#include <time.h>