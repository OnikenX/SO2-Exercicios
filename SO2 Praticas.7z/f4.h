#pragma once

#include "includes.h"

class f4
{
public:
	static int ex2(int argc, LPTSTR argv[]);

	

};

DWORD WINAPI ThreadPares(LPVOID param);

void myThread();
