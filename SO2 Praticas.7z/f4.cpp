#include "f4.h"

int f4::ex2(int argc, LPTSTR argv[]) {

	DWORD threadId = 0;
	HANDLE hTPares = NULL, hTPrimos = NULL;
	int num = 4;
	hTPares = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadPares, &num, 0, &threadId);

	//hTpares = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)myThread,  
	if(hTPares!= NULL)
		_tprintf(TEXT("A thread foi criada.\n"));
	else
		_tprintf(TEXT("A thread n�o foi criada.\n"));

	//if (!CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)myThread, NULL, 0, NULL)) {
	//	_tprintf(TEXT("A thread n�o foi criada.\n"));
	_gettchar();
	return 0;

	

}
DWORD WINAPI ThreadPares(LPVOID param) {
	int i = *(int *)param;
	int contador = 0;

	_tprintf(_TEXT("[Thread %d] Vou come�ar a trabalhar (c�lculo de n�meros pares)%d.\n"), GetCurrentThreadId(),i);
	Sleep(2);

	return 0;
}
