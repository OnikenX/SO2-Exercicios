#include "Ficha.h"


Ficha::Ficha(int total = 1) : exercicios(total) {};
