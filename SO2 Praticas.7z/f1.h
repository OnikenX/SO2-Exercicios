#pragma once

#include "includes.h"

class f1
{
public:
	//exercicio 1 a
	int static ex1a(int argc, LPTSTR argv[]);

	//exercicio 5 d
	int static ex5d(int argc, LPTSTR argv[]);

};

