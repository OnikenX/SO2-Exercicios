#pragma once

#include "includes.h"
class f2
{
public:
	int static ex2(int argc, LPTSTR argv[]);
};

